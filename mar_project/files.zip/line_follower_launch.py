#!/usr/bin/env python3
"""
line_follower_launch.py
Launches:
  1. Gazebo with the custom line-track world
  2. robot_state_publisher with our custom URDF
  3. Spawns the robot at the start of the line track
  4. All three ROS nodes (line_follower, obstacle_detector, control_node)

Usage (from your ~/line-following-robot directory):
  ros2 launch line_follower_launch.py
"""

import os
from launch import LaunchDescription
from launch.actions import (ExecuteProcess, TimerAction,
                             DeclareLaunchArgument)
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


# ── Paths — adjust if you put files elsewhere ───────────────────────────────
REPO_DIR   = os.path.expanduser('~/line-following-robot')
WORLD_FILE = os.path.join(REPO_DIR, 'line_track_world.world')
URDF_FILE  = os.path.join(REPO_DIR, 'line_follower_robot.urdf')


def generate_launch_description():

    # Read URDF text for robot_state_publisher
    with open(URDF_FILE, 'r') as f:
        robot_description = f.read()

    # ── 1. Launch Gazebo with custom world ──────────────────────────────────
    gazebo = ExecuteProcess(
        cmd=['gazebo', '--verbose', WORLD_FILE,
             '-s', 'libgazebo_ros_init.so',
             '-s', 'libgazebo_ros_factory.so'],
        output='screen'
    )

    # ── 2. robot_state_publisher ────────────────────────────────────────────
    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{'robot_description': robot_description,
                     'use_sim_time': True}],
        output='screen'
    )

    # ── 3. Spawn robot at bottom of the track, facing right (+X) ───────────
    spawn = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'line_follower_robot',
            '-topic',  '/robot_description',
            '-x', '0.0',
            '-y', '-0.8',   # start on the bottom straight
            '-z', '0.05',
            '-Y', '0.0',    # facing +X
        ],
        output='screen'
    )

    # ── 4. ROS nodes (delayed 5 s to let Gazebo fully start) ────────────────
    line_follower_node = TimerAction(
        period=5.0,
        actions=[Node(
            package='line_following_robot',
            executable='line_follower',
            name='line_follower',
            output='screen',
            # If running as plain script, use:
            # exec_name='python3', arguments=[os.path.join(REPO_DIR,'line_follower.py')]
        )]
    )

    obstacle_node = TimerAction(
        period=5.0,
        actions=[Node(
            package='line_following_robot',
            executable='obstacle_detector',
            name='obstacle_detector',
            output='screen',
        )]
    )

    control_node = TimerAction(
        period=6.0,   # start slightly after the two sensor nodes
        actions=[Node(
            package='line_following_robot',
            executable='control_node',
            name='control_node',
            output='screen',
        )]
    )

    return LaunchDescription([
        gazebo,
        rsp,
        spawn,
        line_follower_node,
        obstacle_node,
        control_node,
    ])
